/* ========================================================================
 * DOM-based Routing
 * Based on http://goo.gl/EUTi53 by Paul Irish
 *
 * Only fires on body classes that match. If a body class contains a dash,
 * replace the dash with an underscore when adding it to the object below.
 *
 * .noConflict()
 * The routing is enclosed within an anonymous function so that you can
 * always reference jQuery with $, even when in .noConflict() mode.
 * ======================================================================== */

(function($) {

  // Use this variable to set up the common and page specific functions. If you
  // rename this variable, you will also need to rename the namespace below.
  var Sage = {
    // All pages
    'common': {
      init: function() {
        // JavaScript to be fired on all pages
      },
      finalize: function() {
        // JavaScript to be fired on all pages, after page specific JS is fired
      }
    },
    // Home page
    'home': {
      init: function() {
        // JavaScript to be fired on the home page
      },
      finalize: function() {
        // JavaScript to be fired on the home page, after the init JS
      }
    },
    // About us page, note the change from about-us to about_us.
    'about_us': {
      init: function() {
        // JavaScript to be fired on the about us page
      }
    }
  };

  // The routing fires all common scripts, followed by the page specific scripts.
  // Add additional events for more control over timing e.g. a finalize event
  var UTIL = {
    fire: function(func, funcname, args) {
      var fire;
      var namespace = Sage;
      funcname = (funcname === undefined) ? 'init' : funcname;
      fire = func !== '';
      fire = fire && namespace[func];
      fire = fire && typeof namespace[func][funcname] === 'function';

      if (fire) {
        namespace[func][funcname](args);
      }
    },
    loadEvents: function() {
      // Fire common init JS
      UTIL.fire('common');

      // Fire page-specific init JS, and then finalize JS
      $.each(document.body.className.replace(/-/g, '_').split(/\s+/), function(i, classnm) {
        UTIL.fire(classnm);
        UTIL.fire(classnm, 'finalize');
      });

      // Fire common finalize JS
      UTIL.fire('common', 'finalize');
    }
  };

  // Load Events
  $(document).ready(UTIL.loadEvents);

})(jQuery); // Fully reference jQuery after this point.

function centerModals($element) {
  var $modals;
  if ($element.length) {
    $modals = $element;
  } else {
    $modals = jQuery('.modal-vcenter:visible');
  }
  $modals.each( function(i) {
    var $clone = jQuery(this).clone().css('display', 'block').appendTo('body');
    var top = Math.round(($clone.height() - $clone.find('.modal-content').height()) / 2);
    top = top > 0 ? top : 0;
    $clone.remove();
    jQuery(this).find('.modal-content').css("margin-top", top);
  });
}

jQuery('.modal-vcenter').on('show.bs.modal', function(e) {
  centerModals(jQuery(this));
});
jQuery(window).on('resize', centerModals);

jQuery(document).ready(function(){

    jQuery('[data-toggle="tooltip"]').tooltip();   

    var sum = jQuery('.main-footer, .land').get().reduce(function (sum, element) {
      return sum + jQuery(element).outerHeight();
    }, 0);

    jQuery('#affix-nav-affix').affix({
      offset: {
        top: 530,
        bottom: sum
      }
    }).on('affix.bs.affix', function () { // before affix
    jQuery(this).css({
        /*'top': headerHeight,*/    // for fixed height
            'width': jQuery(this).outerWidth()  // variable widths
    });
    }).on('affix-bottom.bs.affix', function () { // before affix-bottom
    jQuery(this).css('bottom', 'auto'); // THIS is what makes the jumping
});

});
    



