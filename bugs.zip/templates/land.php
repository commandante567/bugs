
<div class="land section-container">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Гарантируем уют<br>в доме и на участке!</h2>
                <h3>Обратитесь к специалисту уже сейчас!</h3>
            </div>
            <div class="col-md-6 phone" >
                <div>
               <ul>
                    <li><a href="tel:88129233323">+7(812) 925-33-23</a></li>
			        <li><a href="tel:88129233323">+7(812) 925-33-83</a></li>
                </ul>
                </div> 

<p>Работаем 24 часа 7 дней в неделю</p>
                    <a class="order-call" data-toggle="modal" data-target="#myModal" href="#">
                заказать звонок</a>
            </div>
        </div>
    </div>
</div>
