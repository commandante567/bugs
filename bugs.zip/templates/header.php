<header class="main-header">
  <div class="container">
        <div class="row top">
            <div class="col-md-12 city-nav top-item top-border">
              <span class="grey">Ваш регион: </span>
                <div class="dropdown">
                  <a data-toggle="dropdown" href="#">Санкт-Петербург</a><span class="caret"></span>
                  <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
                    <li><a href="#">Санкт-Петербург</a></li>
                    <li><a href="#">Москва</a></li>
                  </ul>
                </div>
                
                
            </div>
        </div>
    <div class="row logo-area">
        <div class="col-md-7">
            <div class="logo">
                <h1><a href="/"><?php bloginfo('name'); ?></a></h1>
                <span>Санкт-Петербургская<br>городская санитарная служба</span>
            </div>
            <div class="res">
                <span>согласно федеральному закону №213-12 подкрепленно РОСПОТРЕБН</span>
            </div>
        </div>
        <div class="col-md-5 contacts-main">
        <div class="phones">
                                <ul>
                    <li><a href="tel:88129233323">925-33-23,</a></li>
			        <li><a href="tel:88129233323">925-33-83</a></li>
                </ul>          
        </div>
            <div class="callback">
                   <span>Работаем 24 часа 7 дней в неделю</span>
 <a data-toggle="modal" data-target="#myModal" href="#">
                заказать звонок</a>
            </div>
        </div>
    </div>

  </div>
</header>


    <nav class="main-nav-wrap" role="navigation">
    <div class="container">
      <?php
      if (has_nav_menu('primary_navigation')) :
        wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'nav nav-justified main-nav']);
      endif;
?>
</div>
    </nav>

    
